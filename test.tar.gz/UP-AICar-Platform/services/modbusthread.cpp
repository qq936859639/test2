﻿#include "modbusthread.h"

ModbusThread::ModbusThread(QObject *parent) : QThread(parent)
{

}
ModbusThread::~ModbusThread()
{

}
